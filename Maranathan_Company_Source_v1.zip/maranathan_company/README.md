# MARANATHAN COMPANY — version initiale

Application web responsive (Android / ordinateur) pour gérer les clients, dossiers d'immigration, réservations et opérations comptables en XOF et CAD.

## Prérequis
- Node.js 20 ou supérieur
- npm

## Installation locale
1. Décompresser le dossier.
2. Copier `.env.example` vers `.env`.
3. Modifier `SESSION_SECRET`, `ADMIN_EMAIL` et `ADMIN_PASSWORD`.
4. Dans le dossier du projet : `npm install`
5. Démarrer : `npm start`
6. Ouvrir `http://localhost:3000`

## Modules disponibles
- Connexion administrateur par session.
- Fiches clients.
- Dossiers d'immigration et statuts de suivi.
- Réservations de billets / hôtels (enregistrement manuel des fournisseurs, références et confirmations).
- Recettes et dépenses multidevises XOF/CAD.
- Tableau de bord et export CSV.
- Interface responsive et cache de la coque de l'application.

## Important — limites de cette version
Ceci est un MVP fonctionnel de gestion interne, pas encore un système de réservation aérienne/hôtelière connecté aux inventaires mondiaux. La recherche de disponibilités, l'émission de billets et la confirmation d'hôtels nécessitent des contrats et clés API de fournisseurs (par exemple un agrégateur aérien/hôtelier), ainsi que les règles de paiement et de remboursement.
Le mode hors connexion complet avec file d'attente de synchronisation, espace client sécurisé, comptes employés et permissions granulaires, envoi WhatsApp/e-mail, gestion documentaire chiffrée, sauvegardes automatisées et conformité juridique restent à développer avant une utilisation commerciale à grande échelle.

## Sécurité avant production
- Définir des secrets forts dans `.env`; ne jamais publier `.env`.
- Utiliser HTTPS et `NODE_ENV=production`.
- Remplacer le stockage de session mémoire par un magasin de sessions persistant.
- Mettre en place sauvegardes chiffrées, journal d'audit, limitation de tentatives, protection CSRF, contrôle d'accès par rôle et politique de conservation.
- Faire auditer la sécurité et la conformité des traitements de données personnelles avant d'y déposer des passeports ou documents sensibles.

## Structure
- `server.js` : serveur Express, authentification et API.
- `public/index.html` : interface web.
- `public/sw.js` : cache de la coque de l'application.
- `data/` : base SQLite créée automatiquement au premier démarrage.
