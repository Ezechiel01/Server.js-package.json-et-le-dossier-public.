require("dotenv").config();
const express = require("express");
const session = require("express-session");
const helmet = require("helmet");
const bcrypt = require("bcryptjs");
const Database = require("better-sqlite3");
const path = require("path");
const fs = require("fs");

const app = express();
const PORT = process.env.PORT || 3000;
const dataDir = path.join(__dirname, "data");
if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir);
const db = new Database(path.join(dataDir, "maranathan.sqlite"));
db.pragma("journal_mode = WAL");
db.exec(`
CREATE TABLE IF NOT EXISTS users (
 id INTEGER PRIMARY KEY AUTOINCREMENT, email TEXT UNIQUE NOT NULL,
 password_hash TEXT NOT NULL, role TEXT NOT NULL DEFAULT 'admin', created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS clients (
 id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, phone TEXT, email TEXT,
 country TEXT, notes TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS cases (
 id INTEGER PRIMARY KEY AUTOINCREMENT, client_id INTEGER NOT NULL, service TEXT NOT NULL,
 destination TEXT, status TEXT NOT NULL DEFAULT 'Nouveau', due_date TEXT, notes TEXT,
 created_at TEXT DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(client_id) REFERENCES clients(id)
);
CREATE TABLE IF NOT EXISTS bookings (
 id INTEGER PRIMARY KEY AUTOINCREMENT, client_id INTEGER NOT NULL, kind TEXT NOT NULL,
 supplier TEXT, reference TEXT, itinerary TEXT, start_date TEXT, end_date TEXT,
 amount REAL DEFAULT 0, currency TEXT NOT NULL DEFAULT 'XOF', status TEXT DEFAULT 'En attente',
 notes TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(client_id) REFERENCES clients(id)
);
CREATE TABLE IF NOT EXISTS transactions (
 id INTEGER PRIMARY KEY AUTOINCREMENT, client_id INTEGER, kind TEXT NOT NULL,
 category TEXT NOT NULL, description TEXT, amount REAL NOT NULL,
 currency TEXT NOT NULL DEFAULT 'XOF', transaction_date TEXT NOT NULL,
 payment_method TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(client_id) REFERENCES clients(id)
);
`);
const adminEmail = process.env.ADMIN_EMAIL || "admin@maranathancompany.com";
const adminPassword = process.env.ADMIN_PASSWORD || "ChangeThisPassword123!";
if (!db.prepare("SELECT id FROM users WHERE email=?").get(adminEmail)) {
  db.prepare("INSERT INTO users(email,password_hash,role) VALUES(?,?,?)")
    .run(adminEmail, bcrypt.hashSync(adminPassword, 12), "admin");
}

app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: "1mb" }));
app.use(session({
  secret: process.env.SESSION_SECRET || "CHANGE-ME-IN-PRODUCTION",
  resave: false, saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: "lax", secure: process.env.NODE_ENV === "production", maxAge: 8*60*60*1000 }
}));
app.use(express.static(path.join(__dirname, "public")));

function auth(req,res,next) {
  if (!req.session.user) return res.status(401).json({error:"Authentification requise"});
  next();
}
function safeRows(sql, params=[]) { return db.prepare(sql).all(...params); }
function required(body, fields) {
  return fields.filter(f => body[f] === undefined || body[f] === null || String(body[f]).trim()==="");
}

app.post("/api/login", (req,res) => {
  const {email,password} = req.body || {};
  const user = db.prepare("SELECT * FROM users WHERE email=?").get(String(email||"").toLowerCase().trim());
  if (!user || !bcrypt.compareSync(String(password||""), user.password_hash)) return res.status(401).json({error:"Identifiants incorrects"});
  req.session.user = {id:user.id,email:user.email,role:user.role};
  res.json({user:req.session.user});
});
app.post("/api/logout", (req,res) => req.session.destroy(()=>res.json({ok:true})));
app.get("/api/me", (req,res) => res.json({user:req.session.user || null}));

app.get("/api/dashboard", auth, (req,res) => {
  const clients = db.prepare("SELECT COUNT(*) n FROM clients").get().n;
  const cases = db.prepare("SELECT COUNT(*) n FROM cases WHERE status NOT IN ('Terminé','Refusé','Fermé')").get().n;
  const bookings = db.prepare("SELECT COUNT(*) n FROM bookings").get().n;
  const tx = db.prepare("SELECT currency, kind, SUM(amount) total FROM transactions GROUP BY currency,kind").all();
  res.json({clients,cases,bookings,totals:tx});
});

const resources = {
  clients: {table:"clients", fields:["name","phone","email","country","notes"], required:["name"]},
  cases: {table:"cases", fields:["client_id","service","destination","status","due_date","notes"], required:["client_id","service"]},
  bookings: {table:"bookings", fields:["client_id","kind","supplier","reference","itinerary","start_date","end_date","amount","currency","status","notes"], required:["client_id","kind"]},
  transactions: {table:"transactions", fields:["client_id","kind","category","description","amount","currency","transaction_date","payment_method"], required:["kind","category","amount","transaction_date"]}
};
for (const [name, cfg] of Object.entries(resources)) {
  app.get(`/api/${name}`, auth, (req,res) => {
    const join = name==="cases" ? " JOIN clients c ON c.id=t.client_id " :
                 name==="bookings" ? " JOIN clients c ON c.id=t.client_id " : "";
    const select = (name==="cases" || name==="bookings") ? "t.*, c.name client_name" : "t.*";
    res.json(safeRows(`SELECT ${select} FROM ${cfg.table} t${join} ORDER BY t.id DESC`));
  });
  app.post(`/api/${name}`, auth, (req,res) => {
    const body=req.body||{}, missing=required(body,cfg.required);
    if(missing.length) return res.status(400).json({error:"Champs obligatoires manquants: "+missing.join(", ")});
    const cols=cfg.fields.filter(f=>body[f]!==undefined);
    const vals=cols.map(f=>body[f]);
    const result=db.prepare(`INSERT INTO ${cfg.table} (${cols.join(",")}) VALUES (${cols.map(()=>"?").join(",")})`).run(...vals);
    res.status(201).json(db.prepare(`SELECT * FROM ${cfg.table} WHERE id=?`).get(result.lastInsertRowid));
  });
  app.put(`/api/${name}/:id`, auth, (req,res) => {
    const body=req.body||{}, cols=cfg.fields.filter(f=>body[f]!==undefined);
    if(!cols.length) return res.status(400).json({error:"Aucune donnée à modifier"});
    db.prepare(`UPDATE ${cfg.table} SET ${cols.map(f=>f+"=?").join(",")} WHERE id=?`).run(...cols.map(f=>body[f]),req.params.id);
    const row=db.prepare(`SELECT * FROM ${cfg.table} WHERE id=?`).get(req.params.id);
    if(!row) return res.status(404).json({error:"Enregistrement introuvable"});
    res.json(row);
  });
  app.delete(`/api/${name}/:id`, auth, (req,res) => {
    db.prepare(`DELETE FROM ${cfg.table} WHERE id=?`).run(req.params.id);
    res.json({ok:true});
  });
}
app.get("/api/export/:resource", auth, (req,res) => {
  const cfg=resources[req.params.resource];
  if(!cfg) return res.status(404).json({error:"Export inconnu"});
  const rows=db.prepare(`SELECT * FROM ${cfg.table} ORDER BY id DESC`).all();
  const cols=cfg.fields.concat(["id","created_at"]);
  const esc=v=>'"'+String(v??"").replace(/"/g,'""')+'"';
  const csv=[cols.join(";"),...rows.map(r=>cols.map(c=>esc(r[c])).join(";"))].join("\n");
  res.setHeader("Content-Type","text/csv; charset=utf-8");
  res.setHeader("Content-Disposition",`attachment; filename="${req.params.resource}.csv"`);
  res.send("\uFEFF"+csv);
});

app.get("*", (req,res)=>res.sendFile(path.join(__dirname,"public","index.html")));
app.listen(PORT, ()=>console.log(`Maranathan Company lancé sur http://localhost:${PORT}`));
